import os
import json
from datetime import datetime, timedelta
import requests
from dotenv import load_dotenv

load_dotenv()

ACCESS_TOKEN = os.getenv("TIKTOK_ACCESS_TOKEN")
ADVERTISER_ID = os.getenv("TIKTOK_ADVERTISER_ID")
MAX_SPEND = float(os.getenv("MAX_SPEND_WITHOUT_CLICKS", 25.0))
MIN_CLICKS = int(os.getenv("MIN_CLICKS_REQUIRED", 15))
BASE_URL = "https://business-api.tiktok.com/open_api/v1.3"

HEADERS = {
    "Access-Token": ACCESS_TOKEN,
    "Content-Type": "application/json"
}

def get_active_campaigns():
    url = f"{BASE_URL}/campaign/get/"
    params = {
        "advertiser_id": ADVERTISER_ID,
        "filtering": json.dumps({"primary_status": "STATUS_DELIVERY_OK"})
    }
    resp = requests.get(url, headers=HEADERS, params=params, timeout=15).json()
    if resp.get("code") != 0:
        raise RuntimeError(f"Erro ao buscar campanhas: {resp.get('message')}")
    return {c["campaign_id"]: c["campaign_name"] for c in resp.get("data", {}).get("list", [])}

def get_campaign_metrics(campaign_ids):
    if not campaign_ids:
        return {}

    url = f"{BASE_URL}/report/integrated/get/"
    end_date = datetime.now().strftime("%Y-%m-%d")
    start_date = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")

    params = {
        "advertiser_id": ADVERTISER_ID,
        "report_type": "BASIC",
        "dimensions": json.dumps(["campaign_id"]),
        "data_level": "AUCTION_CAMPAIGN",
        "metrics": json.dumps(["spend", "clicks"]),
        "start_date": start_date,
        "end_date": end_date,
        "filtering": json.dumps({"campaign_ids": list(campaign_ids)})
    }
    resp = requests.get(url, headers=HEADERS, params=params, timeout=15).json()
    if resp.get("code") != 0:
        raise RuntimeError(f"Erro ao buscar metricas: {resp.get('message')}")

    metrics_map = {}
    for row in resp.get("data", {}).get("list", []):
        cid = row["dimensions"]["campaign_id"]
        m = row["metrics"]
        metrics_map[cid] = {
            "spend": float(m.get("spend", 0)),
            "clicks": int(m.get("clicks", 0))
        }
    return metrics_map

def pause_campaign(campaign_id):
    url = f"{BASE_URL}/campaign/status/update/"
    payload = {
        "advertiser_id": ADVERTISER_ID,
        "campaign_ids": [campaign_id],
        "operation_status": "DISABLE"
    }
    resp = requests.post(url, headers=HEADERS, json=payload, timeout=15).json()
    return resp.get("code") == 0

def run_stoploss():
    active_campaigns = get_active_campaigns()
    if not active_campaigns:
        print("Nenhuma campanha ativa encontrada no TikTok Ads.")
        return

    metrics = get_campaign_metrics(active_campaigns.keys())

    for cid, name in active_campaigns.items():
        data = metrics.get(cid, {"spend": 0.0, "clicks": 0})
        spend = data["spend"]
        clicks = data["clicks"]

        print(f"Campanha: {name} ({cid}) | Gasto: R$ {spend:.2f} | Cliques: {clicks}")

        if spend >= MAX_SPEND and clicks < MIN_CLICKS:
            if pause_campaign(cid):
                print(f"[STOP-LOSS ACIONADO] Campanha '{name}' pausada automaticamente!")
            else:
                print(f"[ERRO] Falha ao pausar campanha '{name}'. Verifique permissoes do token.")

if __name__ == "__main__":
    run_stoploss()
