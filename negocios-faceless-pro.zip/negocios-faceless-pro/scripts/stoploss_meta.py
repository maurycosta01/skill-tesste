import os
import requests
from dotenv import load_dotenv

load_dotenv()

ACCESS_TOKEN = os.getenv("META_ACCESS_TOKEN")
AD_ACCOUNT_ID = os.getenv("META_AD_ACCOUNT_ID")
MAX_SPEND = float(os.getenv("MAX_SPEND_WITHOUT_CLICKS", 25.0))
MIN_CLICKS = int(os.getenv("MIN_CLICKS_REQUIRED", 15))
API_VERSION = "v21.0"

def check_and_pause_campaigns():
    url = f"https://graph.facebook.com/{API_VERSION}/{AD_ACCOUNT_ID}/campaigns"
    params = {
        "fields": "id,name,status,insights{spend,outbound_clicks}",
        "effective_status": '["ACTIVE"]',
        "access_token": ACCESS_TOKEN
    }
    response = requests.get(url, params=params, timeout=15).json()

    for camp in response.get("data", []):
        camp_id = camp["id"]
        name = camp["name"]
        insights = camp.get("insights", {}).get("data", [])
        if not insights:
            continue

        spend = float(insights[0].get("spend", 0))
        clicks_data = insights[0].get("outbound_clicks", [])
        clicks = int(clicks_data[0]["value"]) if clicks_data else 0

        print(f"Campanha: {name} | Gasto: R$ {spend:.2f} | Cliques de Saida: {clicks}")

        if spend >= MAX_SPEND and clicks < MIN_CLICKS:
            pause_url = f"https://graph.facebook.com/{API_VERSION}/{camp_id}"
            requests.post(pause_url, data={"status": "PAUSED", "access_token": ACCESS_TOKEN}, timeout=15)
            print(f"[STOP-LOSS ACIONADO] Campanha '{name}' pausada para proteger seu caixa!")

if __name__ == "__main__":
    check_and_pause_campaigns()
