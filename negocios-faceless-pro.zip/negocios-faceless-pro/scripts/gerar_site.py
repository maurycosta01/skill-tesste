import json
import os
import sys
from html import escape

TEMPLATE_HTML = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{seo_title}</title>
  <meta name="description" content="{seo_description}" />
  <meta name="robots" content="index, follow" />
  <meta property="og:title" content="{headline}" />
  <meta property="og:description" content="{subheadline}" />
  <meta property="og:type" content="website" />

  <script type="application/ld+json">
  {schema_json}
  </script>

  <!-- META PIXEL -->
  <script>
    !function(f,b,e,v,n,t,s){{if(f.fbq)return;n=f.fbq=function(){{n.callMethod?
    n.callMethod.apply(n,arguments):n.queue.push(arguments)}};if(!f._fbq)f._fbq=n;
    n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
    t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}}(window,
    document,'script','https://connect.facebook.net/en_US/fbevents.js');
    fbq('init', '{meta_pixel_id}');
    fbq('track', 'PageView');
  </script>

  <!-- TIKTOK PIXEL -->
  <script>
    !function (w, d, t) {{
      w.TiktokAnalyticsObject=t;var ttq=w[t]=w[t]||[];ttq.methods=["page","track","identify","instances","debug","on","off","once","ready","alias","group","enableCookie","disableCookie"],ttq.setAndDefer=function(t,e){{t[e]=function(){{t.push([e].concat(Array.prototype.slice.call(arguments,0)))}}}};for(var i=0;i<ttq.methods.length;i++)ttq.setAndDefer(ttq,ttq.methods[i]);ttq.instance=function(t){{for(var e=ttq._i[t]||[],n=0;n<ttq.methods.length;n++)ttq.setAndDefer(e,ttq.methods[n]);return e}},ttq.load=function(e,n){{var i="https://analytics.tiktok.com/i18n/pixel/events.js";ttq._i=ttq._i||{{}},ttq._i[e]=[],ttq._i[e]._u=i,ttq._t=ttq._t||{{}},ttq._t[e]=+new Date,ttq._o=ttq._o||{{}},ttq._o[e]=n||{{}};var o=document.createElement("script");o.type="text/javascript",o.async=!0,o.src=i+"?sdkid="+e+"&lib="+t;var a=document.getElementsByTagName("script")[0];a.parentNode.insertBefore(o,a)}};
      ttq.load('{tiktok_pixel_id}');
      ttq.page();
    }}(window, document, 'ttq');
  </script>

  <style>
    :root {{
      --bg: {cor_fundo}; --card: {cor_card}; --border: #1E293B;
      --text: #F8FAFC; --muted: #94A3B8; --accent: {cor_destaque}; --cta: {cor_cta};
    }}
    * {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: var(--bg); color: var(--text); line-height: 1.6; }}
    .container {{ max-width: 760px; margin: 0 auto; padding: 20px 16px; }}
    header {{ display: flex; justify-content: space-between; align-items: center; padding-bottom: 18px; border-bottom: 1px solid var(--border); }}
    .brand {{ font-weight: 800; font-size: 1.25rem; letter-spacing: -0.02em; }}
    .brand span {{ color: var(--accent); }}
    .badge {{ background: rgba(56, 189, 248, 0.12); color: var(--accent); font-size: 12px; font-weight: 700; padding: 4px 10px; border-radius: 99px; }}
    .hero {{ padding: 28px 0 20px; }}
    h1 {{ font-size: clamp(1.6rem, 4vw, 2.2rem); line-height: 1.2; margin-bottom: 12px; }}
    .hero p {{ color: var(--muted); font-size: 1rem; margin-bottom: 18px; }}
    .card {{ background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 20px; margin-bottom: 18px; }}
    .tag {{ font-size: 12px; font-weight: 700; color: var(--accent); text-transform: uppercase; display: block; margin-bottom: 6px; }}
    h2 {{ font-size: 1.25rem; margin-bottom: 8px; }}
    .desc {{ color: var(--muted); font-size: 0.95rem; margin-bottom: 14px; }}
    .bullets {{ list-style: none; margin-bottom: 16px; font-size: 0.9rem; }}
    .bullets li {{ margin-bottom: 6px; padding-left: 18px; position: relative; }}
    .bullets li::before {{ content: "✓"; color: var(--cta); position: absolute; left: 0; font-weight: bold; }}
    .btn {{ display: block; width: 100%; text-align: center; background: var(--cta); color: #042F2E; font-weight: 800; text-decoration: none; padding: 14px; border-radius: 10px; font-size: 1rem; }}
    .lead-box {{ border: 1px solid var(--accent); border-radius: 14px; padding: 20px; text-align: center; margin: 28px 0; }}
    .btn-outline {{ display: inline-block; margin-top: 12px; border: 1px solid var(--accent); color: var(--accent); padding: 10px 18px; border-radius: 8px; text-decoration: none; font-weight: 700; }}
    footer {{ border-top: 1px solid var(--border); margin-top: 32px; padding-top: 20px; font-size: 12px; color: var(--muted); text-align: center; }}
  </style>
</head>
<body>
  <div class="container">
    <header>
      <div class="brand">{marca_prefixo}<span>{marca_sufixo}</span></div>
      <span class="badge">{selo_topo}</span>
    </header>

    <section class="hero">
      <h1>{headline}</h1>
      <p>{subheadline}</p>
    </section>

    <main>
      {cards_html}

      <section class="lead-box">
        <h3>{lead_titulo}</h3>
        <p class="desc" style="margin-top:6px;">{lead_subtitulo}</p>
        <a href="{lead_link}" target="_blank" class="btn-outline">{lead_cta}</a>
      </section>
    </main>

    <footer>
      <p><strong>{marca_prefixo}{marca_sufixo}</strong> • Todos os direitos reservados.</p>
      <p style="margin-top:6px;">{aviso_legal}</p>
    </footer>
  </div>

  <script>
    function trackOutbound(productName, value) {{
      if (typeof fbq === 'function') {{
        fbq('track', 'InitiateCheckout', {{ content_name: productName, value: value, currency: 'BRL' }});
      }}
      if (typeof ttq === 'object') {{
        ttq.track('InitiateCheckout', {{ content_name: productName, value: value, currency: 'BRL' }});
      }}
    }}
  </script>
</body>
</html>
"""

def build_site(config_path, output_dir="dist"):
    with open(config_path, "r", encoding="utf-8") as f:
        cfg = json.load(f)

    cards = []
    schema_items = []
    for idx, item in enumerate(cfg["ofertas"], start=1):
        bullets_html = "\n".join(f"<li>{escape(b)}</li>" for b in item["beneficios"])
        cards.append(f"""
        <article class="card">
          <span class="tag">{escape(item['tag'])}</span>
          <h2>{escape(item['titulo'])}</h2>
          <p class="desc">{escape(item['descricao'])}</p>
          <ul class="bullets">{bullets_html}</ul>
          <a href="{escape(item['link'])}" target="_blank" rel="nofollow sponsored" class="btn"
             onclick="trackOutbound('{escape(item['titulo'])}', {float(item['preco'])})">
            {escape(item['cta'])} →
          </a>
        </article>""")
        schema_items.append({"@type": "ListItem", "position": idx, "name": item["titulo"]})

    schema_json = json.dumps({
        "@context": "https://schema.org",
        "@type": "ItemList",
        "name": cfg["seo_title"],
        "itemListElement": schema_items
    }, ensure_ascii=False)

    html_final = TEMPLATE_HTML.format(
        seo_title=escape(cfg["seo_title"]),
        seo_description=escape(cfg["seo_description"]),
        headline=escape(cfg["headline"]),
        subheadline=escape(cfg["subheadline"]),
        schema_json=schema_json,
        meta_pixel_id=escape(cfg.get("meta_pixel_id", "SEU_META_PIXEL_ID")),
        tiktok_pixel_id=escape(cfg.get("tiktok_pixel_id", "SEU_TIKTOK_PIXEL_ID")),
        cor_fundo=cfg.get("cor_fundo", "#0B0F19"),
        cor_card=cfg.get("cor_card", "#131A2A"),
        cor_destaque=cfg.get("cor_destaque", "#38BDF8"),
        cor_cta=cfg.get("cor_cta", "#10B981"),
        marca_prefixo=escape(cfg["marca_prefixo"]),
        marca_sufixo=escape(cfg["marca_sufixo"]),
        selo_topo=escape(cfg.get("selo_topo", "Curadoria Verificada")),
        cards_html="\n".join(cards),
        lead_titulo=escape(cfg["lead_titulo"]),
        lead_subtitulo=escape(cfg["lead_subtitulo"]),
        lead_link=escape(cfg["lead_link"]),
        lead_cta=escape(cfg["lead_cta"]),
        aviso_legal=escape(cfg.get("aviso_legal", "Aviso de Transparência (LGPD): Podemos receber comissão por compras feitas através dos links sem custo adicional para você."))
    )

    os.makedirs(output_dir, exist_ok=True)
    out_file = os.path.join(output_dir, "index.html")
    with open(out_file, "w", encoding="utf-8") as f:
        f.write(html_final)
    print(f"Site gerado com sucesso em: {out_file}")

if __name__ == "__main__":
    cfg_file = sys.argv[1] if len(sys.argv) > 1 else "config_negocio.json"
    build_site(cfg_file)
